import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface HighScoreStore {
  highScore: number;
  updateHighScore: (score: number) => boolean;
  resetHighScore: () => void;
}

export const useHighScore = create<HighScoreStore>()(
  persist(
    (set, get) => ({
      highScore: 0,
      
      updateHighScore: (score: number) => {
        const { highScore } = get();
        
        if (score > highScore) {
          set({ highScore: score });
          return true; // New record
        }
        
        return false; // No new record
      },
      
      resetHighScore: () => {
        set({ highScore: 0 });
      }
    }),
    {
      name: 'lightbound-highscore',
      version: 1
    }
  )
);
