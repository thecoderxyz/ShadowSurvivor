import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'LEVEL_TRANSITION' | 'GAME_OVER';
export type PowerUpType = 'shield' | 'speed' | 'slow';
export type Difficulty = 'easy' | 'normal' | 'hard' | 'endless';

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number;
}

export interface DifficultySettings {
  lives: number;
  enemySpeedMultiplier: number;
  enemySpawnMultiplier: number;
  powerUpSpawnRate: number;
}

export const DIFFICULTY_SETTINGS: Record<Difficulty, DifficultySettings> = {
  easy: {
    lives: 5,
    enemySpeedMultiplier: 0.7,
    enemySpawnMultiplier: 0.7,
    powerUpSpawnRate: 1.3
  },
  normal: {
    lives: 3,
    enemySpeedMultiplier: 1.0,
    enemySpawnMultiplier: 1.0,
    powerUpSpawnRate: 1.0
  },
  hard: {
    lives: 2,
    enemySpeedMultiplier: 1.3,
    enemySpawnMultiplier: 1.3,
    powerUpSpawnRate: 0.7
  },
  endless: {
    lives: 1,
    enemySpeedMultiplier: 1.5,
    enemySpawnMultiplier: 1.5,
    powerUpSpawnRate: 0.5
  }
};

interface GameStore {
  // Game State
  gameState: GameState;
  score: number;
  level: number;
  lives: number;
  orbsRemaining: number;
  totalOrbs: number;
  isPaused: boolean;
  combo: number;
  comboTimer: number;
  maxCombo: number;
  activePowerUps: ActivePowerUp[];
  difficulty: Difficulty;

  // Actions
  initializeGame: () => void;
  startGame: (difficulty?: Difficulty) => void;
  pauseGame: () => void;
  resumeGame: () => void;
  restartGame: () => void;
  gameOver: () => void;
  levelComplete: () => void;
  nextLevel: () => void;
  collectOrb: (points: number) => void;
  loseLife: () => void;
  setOrbCount: (remaining: number, total: number) => void;
  addScore: (points: number) => void;
  incrementCombo: () => void;
  resetCombo: () => void;
  updateComboTimer: (delta: number) => void;
  activatePowerUp: (type: PowerUpType) => void;
  updatePowerUps: (delta: number) => void;
  hasPowerUp: (type: PowerUpType) => boolean;
  setDifficulty: (difficulty: Difficulty) => void;
  getDifficultySettings: () => DifficultySettings;
}

export const useGameStore = create<GameStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    gameState: 'START',
    score: 0,
    level: 1,
    lives: 3,
    orbsRemaining: 0,
    totalOrbs: 0,
    isPaused: false,
    combo: 0,
    comboTimer: 0,
    maxCombo: 0,
    activePowerUps: [],
    difficulty: 'normal' as Difficulty,

    // Initialize game
    initializeGame: () => {
      set({
        gameState: 'START',
        score: 0,
        level: 1,
        lives: 3,
        orbsRemaining: 0,
        totalOrbs: 0,
        isPaused: false,
        combo: 0,
        comboTimer: 0,
        maxCombo: 0,
        activePowerUps: []
      });
    },

    // Start game
    startGame: (difficulty: Difficulty = 'normal') => {
      const settings = DIFFICULTY_SETTINGS[difficulty];
      set({
        gameState: 'PLAYING',
        score: 0,
        level: 1,
        lives: settings.lives,
        isPaused: false,
        combo: 0,
        comboTimer: 0,
        maxCombo: 0,
        activePowerUps: [],
        difficulty
      });
    },

    // Pause game
    pauseGame: () => {
      const { gameState } = get();
      if (gameState === 'PLAYING') {
        set({
          gameState: 'PAUSED',
          isPaused: true
        });
      }
    },

    // Resume game
    resumeGame: () => {
      const { gameState } = get();
      if (gameState === 'PAUSED') {
        set({
          gameState: 'PLAYING',
          isPaused: false
        });
      }
    },

    // Restart game
    restartGame: () => {
      const { difficulty } = get();
      const settings = DIFFICULTY_SETTINGS[difficulty];
      set({
        gameState: 'PLAYING',
        score: 0,
        level: 1,
        lives: settings.lives,
        orbsRemaining: 0,
        totalOrbs: 0,
        isPaused: false,
        combo: 0,
        comboTimer: 0,
        maxCombo: 0,
        activePowerUps: []
      });
    },

    // Game over
    gameOver: () => {
      set({
        gameState: 'GAME_OVER',
        isPaused: false
      });
    },

    // Level complete
    levelComplete: () => {
      set({
        gameState: 'LEVEL_TRANSITION'
      });
    },

    // Next level
    nextLevel: () => {
      const { level } = get();
      set({
        gameState: 'PLAYING',
        level: level + 1
      });
    },

    // Collect orb
    collectOrb: (points: number) => {
      const { score, orbsRemaining } = get();
      set({
        score: score + points,
        orbsRemaining: Math.max(0, orbsRemaining - 1)
      });
    },

    // Lose life
    loseLife: () => {
      const { lives } = get();
      const newLives = lives - 1;
      
      if (newLives <= 0) {
        set({
          lives: 0,
          gameState: 'GAME_OVER'
        });
      } else {
        set({
          lives: newLives
        });
      }
    },

    // Set orb count
    setOrbCount: (remaining: number, total: number) => {
      set({
        orbsRemaining: remaining,
        totalOrbs: total
      });
    },

    // Add score
    addScore: (points: number) => {
      const { score } = get();
      set({
        score: score + points
      });
    },

    // Increment combo
    incrementCombo: () => {
      const { combo, maxCombo } = get();
      const newCombo = combo + 1;
      set({
        combo: newCombo,
        comboTimer: 120, // 2 seconds at 60fps
        maxCombo: Math.max(maxCombo, newCombo)
      });
    },

    // Reset combo
    resetCombo: () => {
      set({
        combo: 0,
        comboTimer: 0
      });
    },

    // Update combo timer
    updateComboTimer: (delta: number) => {
      const { comboTimer } = get();
      const newTimer = Math.max(0, comboTimer - delta);
      
      if (newTimer === 0 && comboTimer > 0) {
        set({
          combo: 0,
          comboTimer: 0
        });
      } else {
        set({
          comboTimer: newTimer
        });
      }
    },

    // Activate power-up
    activatePowerUp: (type: PowerUpType) => {
      const { activePowerUps } = get();
      
      // Remove existing power-up of same type
      const filtered = activePowerUps.filter(p => p.type !== type);
      
      // Add new power-up with duration
      const duration = type === 'shield' ? 1 : 300; // Shield lasts until hit, others 5 seconds
      filtered.push({ type, duration });
      
      set({ activePowerUps: filtered });
    },

    // Update power-ups
    updatePowerUps: (delta: number) => {
      const { activePowerUps } = get();
      
      // Update durations and filter out expired ones
      const updated = activePowerUps
        .map(p => ({ ...p, duration: p.duration - delta }))
        .filter(p => p.duration > 0 || p.type === 'shield'); // Shield doesn't expire by time
      
      set({ activePowerUps: updated });
    },

    // Check if has power-up
    hasPowerUp: (type: PowerUpType) => {
      const { activePowerUps } = get();
      return activePowerUps.some(p => p.type === type);
    },

    // Set difficulty
    setDifficulty: (difficulty: Difficulty) => {
      set({ difficulty });
    },

    // Get difficulty settings
    getDifficultySettings: () => {
      const { difficulty } = get();
      return DIFFICULTY_SETTINGS[difficulty];
    }
  }))
);

// Subscribe to keyboard events
if (typeof window !== 'undefined') {
  const handleKeyDown = (event: KeyboardEvent) => {
    const { gameState, pauseGame, resumeGame } = useGameStore.getState();
    
    if (event.key === 'Escape') {
      if (gameState === 'PLAYING') {
        pauseGame();
      } else if (gameState === 'PAUSED') {
        resumeGame();
      }
    }
  };

  window.addEventListener('keydown', handleKeyDown);
}
