export class Orb {
  x: number;
  y: number;
  radius: number;
  pulse: number;
  collected: boolean;
  sparkles: Array<{ x: number; y: number; angle: number; distance: number; alpha: number }>;

  constructor(x: number, y: number, level: number = 1) {
    this.x = x;
    this.y = y;
    this.radius = 8 + Math.min(level * 0.5, 4); // Grow slightly with level
    this.pulse = Math.random() * Math.PI * 2;
    this.collected = false;
    this.sparkles = [];
    
    // Create sparkles around the orb
    for (let i = 0; i < 8; i++) {
      this.sparkles.push({
        x: 0,
        y: 0,
        angle: (Math.PI * 2 * i) / 8,
        distance: this.radius * 2,
        alpha: 1
      });
    }
  }

  update() {
    this.pulse += 0.05;
    
    // Update sparkles
    this.sparkles.forEach(sparkle => {
      sparkle.angle += 0.02;
      sparkle.distance = this.radius * 2 + Math.sin(this.pulse + sparkle.angle) * 4;
      sparkle.x = this.x + Math.cos(sparkle.angle) * sparkle.distance;
      sparkle.y = this.y + Math.sin(sparkle.angle) * sparkle.distance;
      sparkle.alpha = 0.5 + Math.sin(this.pulse * 2 + sparkle.angle) * 0.3;
    });
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.collected) return;

    const scale = 0.8 + Math.sin(this.pulse) * 0.3;
    const currentRadius = this.radius * scale;
    
    // Draw sparkles first
    this.sparkles.forEach(sparkle => {
      ctx.beginPath();
      ctx.fillStyle = `rgba(255, 255, 255, ${sparkle.alpha * 0.7})`;
      ctx.arc(sparkle.x, sparkle.y, 1.5, 0, Math.PI * 2);
      ctx.fill();
    });
    
    // Outer glow
    const outerGlow = ctx.createRadialGradient(
      this.x, this.y, 0,
      this.x, this.y, currentRadius * 2.5
    );
    outerGlow.addColorStop(0, 'rgba(255, 255, 255, 0.6)');
    outerGlow.addColorStop(0.4, 'rgba(255, 255, 255, 0.3)');
    outerGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');
    
    ctx.beginPath();
    ctx.fillStyle = outerGlow;
    ctx.arc(this.x, this.y, currentRadius * 2.5, 0, Math.PI * 2);
    ctx.fill();
    
    // Main orb body
    const gradient = ctx.createRadialGradient(
      this.x - currentRadius * 0.3, this.y - currentRadius * 0.3, 0,
      this.x, this.y, currentRadius
    );
    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.7, 'rgba(200, 200, 255, 0.8)');
    gradient.addColorStop(1, 'rgba(150, 150, 255, 0.6)');
    
    ctx.beginPath();
    ctx.fillStyle = gradient;
    ctx.shadowColor = 'white';
    ctx.shadowBlur = 20;
    ctx.arc(this.x, this.y, currentRadius, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner bright core
    ctx.beginPath();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.shadowBlur = 10;
    ctx.arc(this.x, this.y, currentRadius * 0.5, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowBlur = 0;
  }

  checkCollision(playerX: number, playerY: number, playerRadius: number): boolean {
    if (this.collected) return false;
    
    const dx = playerX - this.x;
    const dy = playerY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    return distance < (playerRadius + this.radius);
  }

  collect() {
    this.collected = true;
  }
}
