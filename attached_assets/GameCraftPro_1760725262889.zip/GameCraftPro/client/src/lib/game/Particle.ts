export interface ParticleOptions {
  x: number;
  y: number;
  color?: string;
  type?: 'explosion' | 'collect' | 'trail' | 'levelup';
  count?: number;
}

export class Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
  decay: number;
  color: string;
  life: number;
  maxLife: number;
  type: string;
  rotation: number;
  rotationSpeed: number;

  constructor(options: ParticleOptions) {
    this.x = options.x;
    this.y = options.y;
    this.type = options.type || 'explosion';
    
    // Set properties based on type
    switch (this.type) {
      case 'explosion':
        this.setupExplosion(options.color || '#ff00ff');
        break;
      case 'collect':
        this.setupCollect(options.color || '#ffffff');
        break;
      case 'trail':
        this.setupTrail(options.color || '#00ffff');
        break;
      case 'levelup':
        this.setupLevelUp(options.color || '#ffff00');
        break;
      default:
        this.setupExplosion(options.color || '#ff00ff');
    }

    this.rotation = Math.random() * Math.PI * 2;
    this.rotationSpeed = (Math.random() - 0.5) * 0.2;
  }

  private setupExplosion(color: string) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 8 + 2;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.radius = Math.random() * 4 + 1;
    this.alpha = 1;
    this.decay = Math.random() * 0.03 + 0.02;
    this.color = color;
    this.maxLife = this.life = 60;
  }

  private setupCollect(color: string) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 3 + 1;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed - 1; // Slight upward bias
    this.radius = Math.random() * 3 + 2;
    this.alpha = 1;
    this.decay = Math.random() * 0.02 + 0.015;
    this.color = color;
    this.maxLife = this.life = 80;
  }

  private setupTrail(color: string) {
    this.vx = (Math.random() - 0.5) * 2;
    this.vy = (Math.random() - 0.5) * 2;
    this.radius = Math.random() * 2 + 0.5;
    this.alpha = 0.8;
    this.decay = Math.random() * 0.04 + 0.02;
    this.color = color;
    this.maxLife = this.life = 30;
  }

  private setupLevelUp(color: string) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 6 + 3;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.radius = Math.random() * 5 + 2;
    this.alpha = 1;
    this.decay = Math.random() * 0.015 + 0.01;
    this.color = color;
    this.maxLife = this.life = 120;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= this.decay;
    this.life--;
    this.rotation += this.rotationSpeed;

    // Apply some physics based on type
    switch (this.type) {
      case 'explosion':
        this.vx *= 0.98;
        this.vy *= 0.98;
        this.vy += 0.1; // Gravity
        break;
      case 'collect':
        this.vx *= 0.95;
        this.vy *= 0.95;
        this.vy -= 0.05; // Anti-gravity effect
        break;
      case 'trail':
        this.vx *= 0.99;
        this.vy *= 0.99;
        break;
      case 'levelup':
        this.vx *= 0.99;
        this.vy *= 0.99;
        // Sparkle effect - random position changes
        if (Math.random() < 0.1) {
          this.vx += (Math.random() - 0.5) * 2;
          this.vy += (Math.random() - 0.5) * 2;
        }
        break;
    }

    return this.alpha > 0 && this.life > 0;
  }

  draw(ctx: CanvasRenderingContext2D) {
    const fadeAlpha = Math.min(this.alpha, this.life / this.maxLife);
    
    if (fadeAlpha <= 0) return;

    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);

    switch (this.type) {
      case 'explosion':
        this.drawExplosion(ctx, fadeAlpha);
        break;
      case 'collect':
        this.drawCollect(ctx, fadeAlpha);
        break;
      case 'trail':
        this.drawTrail(ctx, fadeAlpha);
        break;
      case 'levelup':
        this.drawLevelUp(ctx, fadeAlpha);
        break;
    }

    ctx.restore();
  }

  private drawExplosion(ctx: CanvasRenderingContext2D, alpha: number) {
    // Outer glow
    const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.radius * 2);
    gradient.addColorStop(0, this.color + Math.floor(alpha * 255).toString(16).padStart(2, '0'));
    gradient.addColorStop(0.5, this.color + Math.floor(alpha * 128).toString(16).padStart(2, '0'));
    gradient.addColorStop(1, this.color + '00');

    ctx.beginPath();
    ctx.fillStyle = gradient;
    ctx.arc(0, 0, this.radius * 2, 0, Math.PI * 2);
    ctx.fill();

    // Core
    ctx.beginPath();
    ctx.fillStyle = this.color + Math.floor(alpha * 255).toString(16).padStart(2, '0');
    ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawCollect(ctx: CanvasRenderingContext2D, alpha: number) {
    // Bright sparkle effect
    ctx.beginPath();
    ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 10;
    ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
    ctx.fill();

    // Cross sparkle
    ctx.beginPath();
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.8})`;
    ctx.lineWidth = 2;
    ctx.shadowBlur = 5;
    ctx.moveTo(-this.radius * 1.5, 0);
    ctx.lineTo(this.radius * 1.5, 0);
    ctx.moveTo(0, -this.radius * 1.5);
    ctx.lineTo(0, this.radius * 1.5);
    ctx.stroke();
    
    ctx.shadowBlur = 0;
  }

  private drawTrail(ctx: CanvasRenderingContext2D, alpha: number) {
    ctx.beginPath();
    ctx.fillStyle = this.color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
    ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawLevelUp(ctx: CanvasRenderingContext2D, alpha: number) {
    // Rotating star shape
    ctx.beginPath();
    ctx.fillStyle = `rgba(255, 255, 0, ${alpha})`;
    ctx.shadowColor = '#ffff00';
    ctx.shadowBlur = 15;

    // Draw star
    const spikes = 5;
    const outerRadius = this.radius;
    const innerRadius = this.radius * 0.4;

    let rot = (Math.PI / 2) * 3;
    const step = Math.PI / spikes;

    ctx.moveTo(0, -outerRadius);
    
    for (let i = 0; i < spikes; i++) {
      ctx.lineTo(Math.cos(rot) * outerRadius, Math.sin(rot) * outerRadius);
      rot += step;
      ctx.lineTo(Math.cos(rot) * innerRadius, Math.sin(rot) * innerRadius);
      rot += step;
    }
    
    ctx.lineTo(0, -outerRadius);
    ctx.closePath();
    ctx.fill();
    
    ctx.shadowBlur = 0;
  }
}

export class ParticleSystem {
  particles: Particle[];

  constructor() {
    this.particles = [];
  }

  createParticles(options: ParticleOptions) {
    const count = options.count || 15;
    
    for (let i = 0; i < count; i++) {
      this.particles.push(new Particle({
        ...options,
        // Add some randomness to position
        x: options.x + (Math.random() - 0.5) * 10,
        y: options.y + (Math.random() - 0.5) * 10
      }));
    }
  }

  update() {
    this.particles = this.particles.filter(particle => particle.update());
  }

  draw(ctx: CanvasRenderingContext2D) {
    this.particles.forEach(particle => particle.draw(ctx));
  }

  clear() {
    this.particles = [];
  }
}
