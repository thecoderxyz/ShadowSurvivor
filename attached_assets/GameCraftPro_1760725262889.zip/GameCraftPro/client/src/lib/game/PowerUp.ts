export type PowerUpType = 'shield' | 'speed' | 'slow';

export interface PowerUpEffect {
  type: PowerUpType;
  duration: number;
  active: boolean;
}

export class PowerUp {
  x: number;
  y: number;
  radius: number;
  type: PowerUpType;
  collected: boolean;
  pulse: number;
  rotation: number;
  particles: Array<{ angle: number; distance: number; speed: number }>;

  constructor(x: number, y: number, type?: PowerUpType) {
    this.x = x;
    this.y = y;
    this.radius = 15;
    this.type = type || this.randomType();
    this.collected = false;
    this.pulse = Math.random() * Math.PI * 2;
    this.rotation = 0;
    this.particles = [];
    
    // Create orbiting particles
    for (let i = 0; i < 6; i++) {
      this.particles.push({
        angle: (Math.PI * 2 * i) / 6,
        distance: this.radius * 2,
        speed: 0.05 + Math.random() * 0.03
      });
    }
  }

  private randomType(): PowerUpType {
    const types: PowerUpType[] = ['shield', 'speed', 'slow'];
    return types[Math.floor(Math.random() * types.length)];
  }

  update() {
    this.pulse += 0.06;
    this.rotation += 0.03;
    
    // Update orbiting particles
    this.particles.forEach(particle => {
      particle.angle += particle.speed;
    });
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.collected) return;

    const pulseMagnitude = 0.85 + Math.sin(this.pulse) * 0.15;
    const currentRadius = this.radius * pulseMagnitude;
    
    // Get color based on type
    let color, glowColor, symbol;
    switch (this.type) {
      case 'shield':
        color = '#4169E1';
        glowColor = '#1E90FF';
        symbol = '🛡️';
        break;
      case 'speed':
        color = '#00FF00';
        glowColor = '#00CC00';
        symbol = '⚡';
        break;
      case 'slow':
        color = '#9370DB';
        glowColor = '#8A2BE2';
        symbol = '❄️';
        break;
    }
    
    // Draw orbiting particles
    this.particles.forEach(particle => {
      const particleX = this.x + Math.cos(particle.angle) * particle.distance;
      const particleY = this.y + Math.sin(particle.angle) * particle.distance;
      
      ctx.beginPath();
      ctx.fillStyle = color + '80';
      ctx.arc(particleX, particleY, 2, 0, Math.PI * 2);
      ctx.fill();
    });
    
    // Outer glow
    const gradient = ctx.createRadialGradient(
      this.x, this.y, 0,
      this.x, this.y, currentRadius * 2.5
    );
    gradient.addColorStop(0, glowColor + '80');
    gradient.addColorStop(0.5, glowColor + '40');
    gradient.addColorStop(1, glowColor + '00');
    
    ctx.beginPath();
    ctx.fillStyle = gradient;
    ctx.arc(this.x, this.y, currentRadius * 2.5, 0, Math.PI * 2);
    ctx.fill();
    
    // Main power-up body
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    
    // Draw hexagon shape
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i;
      const x = Math.cos(angle) * currentRadius;
      const y = Math.sin(angle) * currentRadius;
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    
    ctx.fillStyle = color;
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 20;
    ctx.fill();
    
    // Inner glow
    ctx.beginPath();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.arc(0, 0, currentRadius * 0.6, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
    ctx.shadowBlur = 0;
    
    // Draw symbol (using text as emoji fallback)
    ctx.save();
    ctx.font = `${currentRadius * 1.2}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'white';
    
    // Use text instead of emoji for better compatibility
    let text = '';
    switch (this.type) {
      case 'shield':
        text = 'S';
        break;
      case 'speed':
        text = '+';
        break;
      case 'slow':
        text = '-';
        break;
    }
    
    ctx.fillText(text, this.x, this.y);
    ctx.restore();
  }

  checkCollision(playerX: number, playerY: number, playerRadius: number): boolean {
    if (this.collected) return false;
    
    const dx = playerX - this.x;
    const dy = playerY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    return distance < (playerRadius + this.radius);
  }

  collect() {
    this.collected = true;
  }
}
