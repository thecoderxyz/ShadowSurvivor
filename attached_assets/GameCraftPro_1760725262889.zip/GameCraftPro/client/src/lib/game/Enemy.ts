export class Enemy {
  x: number;
  y: number;
  radius: number;
  speed: number;
  targetX: number;
  targetY: number;
  pulse: number;
  type: 'chaser' | 'orbiter' | 'hunter';
  orbitAngle: number;
  orbitRadius: number;
  huntCooldown: number;
  maxHuntCooldown: number;
  width: number;
  height: number;

  constructor(width: number, height: number, level: number = 1) {
    this.width = width;
    this.height = height;
    this.radius = 10 + Math.min(level * 0.5, 5);
    this.pulse = Math.random() * Math.PI * 2;
    
    // Spawn from random edge
    const side = Math.floor(Math.random() * 4);
    if (side === 0) { // Top
      this.x = Math.random() * width;
      this.y = -this.radius * 2;
    } else if (side === 1) { // Right
      this.x = width + this.radius * 2;
      this.y = Math.random() * height;
    } else if (side === 2) { // Bottom
      this.x = Math.random() * width;
      this.y = height + this.radius * 2;
    } else { // Left
      this.x = -this.radius * 2;
      this.y = Math.random() * height;
    }

    // Set enemy type based on level
    if (level <= 2) {
      this.type = 'chaser';
    } else if (level <= 5) {
      this.type = Math.random() < 0.7 ? 'chaser' : 'orbiter';
    } else {
      const rand = Math.random();
      if (rand < 0.5) this.type = 'chaser';
      else if (rand < 0.8) this.type = 'orbiter';
      else this.type = 'hunter';
    }

    // Set speed based on level and type
    const baseSpeed = 0.8 + (level * 0.15);
    switch (this.type) {
      case 'chaser':
        this.speed = baseSpeed;
        break;
      case 'orbiter':
        this.speed = baseSpeed * 0.7;
        this.orbitAngle = Math.random() * Math.PI * 2;
        this.orbitRadius = 100 + Math.random() * 50;
        break;
      case 'hunter':
        this.speed = baseSpeed * 1.3;
        this.huntCooldown = 0;
        this.maxHuntCooldown = 120; // 2 seconds at 60fps
        break;
    }

    this.targetX = this.x;
    this.targetY = this.y;
  }

  update(playerX: number, playerY: number) {
    this.pulse += 0.06;

    switch (this.type) {
      case 'chaser':
        this.updateChaser(playerX, playerY);
        break;
      case 'orbiter':
        this.updateOrbiter(playerX, playerY);
        break;
      case 'hunter':
        this.updateHunter(playerX, playerY);
        break;
    }

    // Keep enemy roughly in bounds (allow some overflow for dramatic effect)
    const margin = this.radius * 3;
    if (this.x < -margin || this.x > this.width + margin || 
        this.y < -margin || this.y > this.height + margin) {
      // Respawn from a random edge
      const side = Math.floor(Math.random() * 4);
      if (side === 0) { // Top
        this.x = Math.random() * this.width;
        this.y = -this.radius * 2;
      } else if (side === 1) { // Right
        this.x = this.width + this.radius * 2;
        this.y = Math.random() * this.height;
      } else if (side === 2) { // Bottom
        this.x = Math.random() * this.width;
        this.y = this.height + this.radius * 2;
      } else { // Left
        this.x = -this.radius * 2;
        this.y = Math.random() * this.height;
      }
    }
  }

  private updateChaser(playerX: number, playerY: number) {
    const dx = playerX - this.x;
    const dy = playerY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance > 1) {
      this.x += (dx / distance) * this.speed;
      this.y += (dy / distance) * this.speed;
    }
  }

  private updateOrbiter(playerX: number, playerY: number) {
    this.orbitAngle += 0.02;
    
    // Calculate orbit position around player
    const orbitX = playerX + Math.cos(this.orbitAngle) * this.orbitRadius;
    const orbitY = playerY + Math.sin(this.orbitAngle) * this.orbitRadius;
    
    // Move towards orbit position
    const dx = orbitX - this.x;
    const dy = orbitY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance > 1) {
      this.x += (dx / distance) * this.speed;
      this.y += (dy / distance) * this.speed;
    }
    
    // Gradually decrease orbit radius to close in
    this.orbitRadius = Math.max(50, this.orbitRadius - 0.1);
  }

  private updateHunter(playerX: number, playerY: number) {
    this.huntCooldown--;
    
    if (this.huntCooldown <= 0) {
      // Calculate direct path to player
      const dx = playerX - this.x;
      const dy = playerY - this.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance > 1) {
        // Fast movement towards player
        this.x += (dx / distance) * this.speed;
        this.y += (dy / distance) * this.speed;
      }
      
      // Reset cooldown after reaching close to player
      if (distance < 50) {
        this.huntCooldown = this.maxHuntCooldown;
      }
    } else {
      // Slower movement while in cooldown
      const dx = playerX - this.x;
      const dy = playerY - this.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance > 1) {
        this.x += (dx / distance) * (this.speed * 0.3);
        this.y += (dy / distance) * (this.speed * 0.3);
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    const pulseMagnitude = Math.sin(this.pulse) * 2;
    const currentRadius = this.radius + pulseMagnitude;
    
    // Get color based on type
    let color, glowColor;
    switch (this.type) {
      case 'chaser':
        color = '#2c003e';
        glowColor = '#ff00ff';
        break;
      case 'orbiter':
        color = '#3e0020';
        glowColor = '#ff0080';
        break;
      case 'hunter':
        color = '#3e0000';
        glowColor = '#ff4000';
        break;
    }
    
    // Outer menacing glow
    const outerGlow = ctx.createRadialGradient(
      this.x, this.y, 0,
      this.x, this.y, currentRadius * 3
    );
    outerGlow.addColorStop(0, `${glowColor}60`);
    outerGlow.addColorStop(0.5, `${glowColor}20`);
    outerGlow.addColorStop(1, `${glowColor}00`);
    
    ctx.beginPath();
    ctx.fillStyle = outerGlow;
    ctx.arc(this.x, this.y, currentRadius * 3, 0, Math.PI * 2);
    ctx.fill();
    
    // Main enemy body
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 30;
    ctx.arc(this.x, this.y, currentRadius, 0, Math.PI * 2);
    ctx.fill();
    
    // Dark core for contrast
    ctx.beginPath();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.shadowBlur = 0;
    ctx.arc(this.x, this.y, currentRadius * 0.4, 0, Math.PI * 2);
    ctx.fill();
    
    // Hunter special effect - charging indicator
    if (this.type === 'hunter' && this.huntCooldown > 0) {
      const chargeProgress = 1 - (this.huntCooldown / this.maxHuntCooldown);
      ctx.beginPath();
      ctx.strokeStyle = '#ff4000';
      ctx.lineWidth = 3;
      ctx.setLineDash([5, 5]);
      ctx.arc(this.x, this.y, currentRadius * 1.5, 0, Math.PI * 2 * chargeProgress);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    
    ctx.shadowBlur = 0;
  }

  checkCollision(playerX: number, playerY: number, playerRadius: number): boolean {
    const dx = playerX - this.x;
    const dy = playerY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    return distance < (playerRadius + this.radius * 0.8); // Slightly more forgiving collision
  }

  resize(width: number, height: number) {
    this.width = width;
    this.height = height;
  }
}
