export interface LevelTheme {
  name: string;
  backgroundColor: { start: string; end: string };
  dustColor: string;
  accentHue: number; // Used for particles and effects
  enemyGlow: string;
  orbTint: number; // Hue adjustment for orbs
}

export const themes: LevelTheme[] = [
  {
    name: 'Void',
    backgroundColor: { start: '#0a0a2e', end: '#02020a' },
    dustColor: 'rgba(255, 255, 255, 0.3)',
    accentHue: 180, // Cyan
    enemyGlow: '#ff00ff',
    orbTint: 0
  },
  {
    name: 'Neon City',
    backgroundColor: { start: '#1a0a2e', end: '#0a0520' },
    dustColor: 'rgba(255, 0, 255, 0.3)',
    accentHue: 300, // Magenta
    enemyGlow: '#00ffff',
    orbTint: 60
  },
  {
    name: 'Electric Dreams',
    backgroundColor: { start: '#0a2e0a', end: '#020a02' },
    dustColor: 'rgba(0, 255, 100, 0.3)',
    accentHue: 120, // Green
    enemyGlow: '#ffff00',
    orbTint: 120
  },
  {
    name: 'Solar Flare',
    backgroundColor: { start: '#2e1a0a', end: '#0a0502' },
    dustColor: 'rgba(255, 150, 0, 0.3)',
    accentHue: 30, // Orange
    enemyGlow: '#ff0080',
    orbTint: 30
  },
  {
    name: 'Deep Space',
    backgroundColor: { start: '#0a0a2e', end: '#000005' },
    dustColor: 'rgba(100, 100, 255, 0.3)',
    accentHue: 240, // Blue
    enemyGlow: '#00ff80',
    orbTint: 240
  },
  {
    name: 'Crimson Abyss',
    backgroundColor: { start: '#2e0a0a', end: '#0a0202' },
    dustColor: 'rgba(255, 50, 50, 0.3)',
    accentHue: 0, // Red
    enemyGlow: '#ff00ff',
    orbTint: 0
  }
];

export function getThemeForLevel(level: number): LevelTheme {
  const themeIndex = Math.floor((level - 1) / 3) % themes.length;
  return themes[themeIndex];
}
