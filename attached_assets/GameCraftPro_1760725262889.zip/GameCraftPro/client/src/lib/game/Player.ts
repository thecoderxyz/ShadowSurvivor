export interface Touch {
  x: number | null;
  y: number | null;
  active: boolean;
}

export class Player {
  x: number;
  y: number;
  radius: number;
  speed: number;
  color: string;
  trail: Array<{ x: number; y: number; alpha: number; radius: number }>;
  pulse: number;
  width: number;
  height: number;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.x = width / 2;
    this.y = height / 2;
    this.radius = 12;
    this.speed = 4;
    this.color = `hsl(180, 100%, 75%)`;
    this.trail = [];
    this.pulse = 0;
  }

  update(keys: Record<string, boolean>, touch: Touch, level: number, speedMultiplier: number = 1.0) {
    // Update color based on level for variety
    this.color = `hsl(${180 + level * 15}, 100%, 75%)`;
    
    // Keyboard movement with speed multiplier
    const effectiveSpeed = this.speed * speedMultiplier;
    let moveX = 0;
    let moveY = 0;
    
    if (keys['ArrowUp'] || keys['w'] || keys['W']) moveY -= effectiveSpeed;
    if (keys['ArrowDown'] || keys['s'] || keys['S']) moveY += effectiveSpeed;
    if (keys['ArrowLeft'] || keys['a'] || keys['A']) moveX -= effectiveSpeed;
    if (keys['ArrowRight'] || keys['d'] || keys['D']) moveX += effectiveSpeed;

    // Touch movement with speed multiplier
    if (touch.active && touch.x !== null && touch.y !== null) {
      const dx = touch.x - this.x;
      const dy = touch.y - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      if (dist > effectiveSpeed) {
        moveX = (dx / dist) * effectiveSpeed;
        moveY = (dy / dist) * effectiveSpeed;
      } else {
        moveX = dx;
        moveY = dy;
      }
    }

    // Apply movement
    this.x += moveX;
    this.y += moveY;

    // Keep player within bounds with some padding
    const padding = this.radius;
    this.x = Math.max(padding, Math.min(this.width - padding, this.x));
    this.y = Math.max(padding, Math.min(this.height - padding, this.y));

    // Add to trail
    this.trail.push({ 
      x: this.x, 
      y: this.y, 
      alpha: 1, 
      radius: this.radius * 0.4 
    });
    
    if (this.trail.length > 100) {
      this.trail.shift();
    }
    
    // Update trail opacity
    this.trail.forEach(p => p.alpha -= 0.012);
    this.trail = this.trail.filter(p => p.alpha > 0);

    // Update pulse for glow effect
    this.pulse += 0.08;
  }

  draw(ctx: CanvasRenderingContext2D) {
    // Draw trail
    this.trail.forEach((p, index) => {
      const alpha = p.alpha * 0.6;
      const size = p.radius * (0.5 + alpha * 0.5);
      
      ctx.beginPath();
      ctx.fillStyle = `hsla(180, 100%, 75%, ${alpha})`;
      ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
      ctx.fill();
      
      // Add inner glow to trail
      if (alpha > 0.3) {
        ctx.beginPath();
        ctx.fillStyle = `hsla(180, 100%, 90%, ${alpha * 0.3})`;
        ctx.arc(p.x, p.y, size * 0.6, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    
    // Draw player with pulsing glow
    const pulseMagnitude = 3 + Math.sin(this.pulse) * 2;
    const glowRadius = this.radius + pulseMagnitude;
    
    // Outer glow
    const gradient = ctx.createRadialGradient(
      this.x, this.y, 0,
      this.x, this.y, glowRadius * 1.8
    );
    gradient.addColorStop(0, 'hsla(180, 100%, 75%, 0.8)');
    gradient.addColorStop(0.3, 'hsla(180, 100%, 75%, 0.4)');
    gradient.addColorStop(0.6, 'hsla(180, 100%, 75%, 0.1)');
    gradient.addColorStop(1, 'hsla(180, 100%, 75%, 0)');
    
    ctx.beginPath();
    ctx.fillStyle = gradient;
    ctx.arc(this.x, this.y, glowRadius * 1.8, 0, Math.PI * 2);
    ctx.fill();
    
    // Main player body
    ctx.beginPath();
    ctx.fillStyle = this.color;
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 25;
    ctx.arc(this.x, this.y, glowRadius, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner bright core
    ctx.beginPath();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.shadowBlur = 15;
    ctx.arc(this.x, this.y, glowRadius * 0.6, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowBlur = 0;
  }

  resize(width: number, height: number) {
    this.width = width;
    this.height = height;
    
    // Keep player in bounds after resize
    const padding = this.radius;
    this.x = Math.max(padding, Math.min(width - padding, this.x));
    this.y = Math.max(padding, Math.min(height - padding, this.y));
  }
}
