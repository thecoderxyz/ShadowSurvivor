import { Player, Touch } from './Player';
import { Orb } from './Orb';
import { Enemy } from './Enemy';
import { ParticleSystem } from './Particle';
import { PowerUp, PowerUpType } from './PowerUp';
import { useGameStore } from '../stores/useGameStore';
import { AudioManager } from '../audio/AudioManager';
import { getThemeForLevel, LevelTheme } from './LevelThemes';

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animationId: number | null = null;
  private isRunning = false;

  // Game objects
  private player: Player;
  private orbs: Orb[] = [];
  private enemies: Enemy[] = [];
  private powerUps: PowerUp[] = [];
  private particleSystem: ParticleSystem;
  private dustParticles: Array<{ x: number; y: number; radius: number; alpha: number }> = [];
  private powerUpSpawnTimer: number = 0;

  // Input handling
  private keys: Record<string, boolean> = {};
  private touch: Touch = { x: null, y: null, active: false };

  // Game state
  private gameState: string = 'START';
  private levelTransitionTimer = 0;
  private invulnerabilityTimer = 0;
  private lastTime = 0;
  
  // Screen shake
  private shakeIntensity = 0;
  private shakeDuration = 0;
  
  // Theme
  private currentTheme: LevelTheme;

  // Audio
  private audioManager: AudioManager;

  constructor(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D) {
    this.canvas = canvas;
    this.ctx = ctx;
    this.player = new Player(canvas.width, canvas.height);
    this.particleSystem = new ParticleSystem();
    this.audioManager = AudioManager.getInstance();
    this.currentTheme = getThemeForLevel(1);

    this.setupEventListeners();
    this.generateDustParticles();
  }

  private setupEventListeners() {
    // Keyboard events
    window.addEventListener('keydown', (e) => {
      this.keys[e.key] = true;
    });

    window.addEventListener('keyup', (e) => {
      this.keys[e.key] = false;
    });

    // Touch events
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.touch.active = true;
      const rect = this.canvas.getBoundingClientRect();
      this.touch.x = e.touches[0].clientX - rect.left;
      this.touch.y = e.touches[0].clientY - rect.top;
    });

    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      if (this.touch.active) {
        const rect = this.canvas.getBoundingClientRect();
        this.touch.x = e.touches[0].clientX - rect.left;
        this.touch.y = e.touches[0].clientY - rect.top;
      }
    });

    this.canvas.addEventListener('touchend', (e) => {
      e.preventDefault();
      this.touch.active = false;
    });

    // Mouse events for desktop
    this.canvas.addEventListener('mousedown', (e) => {
      if (this.gameState === 'PLAYING') {
        const rect = this.canvas.getBoundingClientRect();
        this.touch.active = true;
        this.touch.x = e.clientX - rect.left;
        this.touch.y = e.clientY - rect.top;
      }
    });

    this.canvas.addEventListener('mousemove', (e) => {
      if (this.touch.active && this.gameState === 'PLAYING') {
        const rect = this.canvas.getBoundingClientRect();
        this.touch.x = e.clientX - rect.left;
        this.touch.y = e.clientY - rect.top;
      }
    });

    this.canvas.addEventListener('mouseup', () => {
      this.touch.active = false;
    });
  }

  private generateDustParticles() {
    this.dustParticles = [];
    for (let i = 0; i < 150; i++) {
      this.dustParticles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        radius: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.2 + 0.05
      });
    }
  }

  private setupLevel() {
    const gameStore = useGameStore.getState();
    const level = gameStore.level;
    
    // Update theme for new level
    this.currentTheme = getThemeForLevel(level);
    
    // Regenerate dust with theme color
    this.generateDustParticles();
    
    // Clear existing objects
    this.orbs = [];
    this.enemies = [];
    this.powerUps = [];
    this.particleSystem.clear();
    this.powerUpSpawnTimer = 600; // Spawn first power-up after 10 seconds
    
    // Create orbs - more orbs at higher levels
    const orbCount = 5 + level + Math.floor(level / 3);
    for (let i = 0; i < orbCount; i++) {
      let x, y;
      let attempts = 0;
      
      do {
        x = Math.random() * (this.canvas.width - 100) + 50;
        y = Math.random() * (this.canvas.height - 100) + 50;
        attempts++;
      } while (
        attempts < 50 && 
        Math.sqrt((x - this.player.x) ** 2 + (y - this.player.y) ** 2) < 100
      );
      
      this.orbs.push(new Orb(x, y, level));
    }
    
    // Create enemies - more enemies and variety at higher levels, adjusted by difficulty
    const diffSettings = gameStore.getDifficultySettings();
    const enemyCount = Math.min(Math.floor((1 + Math.floor(level / 2)) * diffSettings.enemySpawnMultiplier), 10);
    for (let i = 0; i < enemyCount; i++) {
      const enemy = new Enemy(this.canvas.width, this.canvas.height, level);
      // Apply difficulty speed multiplier
      enemy.speed *= diffSettings.enemySpeedMultiplier;
      this.enemies.push(enemy);
    }

    // Update game store
    gameStore.setOrbCount(this.orbs.length, this.orbs.length);
    
    // Reset invulnerability
    this.invulnerabilityTimer = 0;
  }

  private update(deltaTime: number) {
    const gameStore = useGameStore.getState();
    
    if (this.gameState !== 'PLAYING') return;

    // Update invulnerability timer
    if (this.invulnerabilityTimer > 0) {
      this.invulnerabilityTimer--;
    }

    // Update screen shake
    if (this.shakeDuration > 0) {
      this.shakeDuration--;
      this.shakeIntensity *= 0.9; // Decay shake
    } else {
      this.shakeIntensity = 0;
    }

    // Update combo timer
    gameStore.updateComboTimer(1);

    // Update power-ups
    gameStore.updatePowerUps(1);

    // Apply power-up effects to player speed
    const speedMultiplier = gameStore.hasPowerUp('speed') ? 1.5 : 1.0;

    // Update player
    this.player.update(this.keys, this.touch, gameStore.level, speedMultiplier);

    // Update orbs
    this.orbs.forEach(orb => orb.update());

    // Update power-ups
    this.powerUps.forEach(powerUp => powerUp.update());

    // Apply slow effect to enemies
    const enemySpeedMultiplier = gameStore.hasPowerUp('slow') ? 0.3 : 1.0;

    // Update enemies with speed modifier
    this.enemies.forEach(enemy => {
      const originalSpeed = enemy.speed;
      enemy.speed = originalSpeed * enemySpeedMultiplier;
      enemy.update(this.player.x, this.player.y);
      enemy.speed = originalSpeed; // Restore original speed
    });

    // Update particles
    this.particleSystem.update();

    // Power-up spawning logic with difficulty adjustment
    const diffSettings = gameStore.getDifficultySettings();
    this.powerUpSpawnTimer--;
    const powerUpInterval = Math.floor(900 / diffSettings.powerUpSpawnRate);
    
    if (this.powerUpSpawnTimer <= 0 && this.powerUps.length < 2) {
      // Spawn power-up at random position away from player
      let x, y;
      let attempts = 0;
      do {
        x = Math.random() * (this.canvas.width - 100) + 50;
        y = Math.random() * (this.canvas.height - 100) + 50;
        attempts++;
      } while (
        attempts < 50 &&
        Math.sqrt((x - this.player.x) ** 2 + (y - this.player.y) ** 2) < 150
      );
      
      this.powerUps.push(new PowerUp(x, y));
      this.powerUpSpawnTimer = powerUpInterval; // Next power-up adjusted by difficulty
    }

    // Check power-up collisions
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const powerUp = this.powerUps[i];
      if (powerUp.checkCollision(this.player.x, this.player.y, this.player.radius)) {
        powerUp.collect();
        this.powerUps.splice(i, 1);
        
        // Activate power-up
        gameStore.activatePowerUp(powerUp.type);
        
        // Create particles
        let color = '#00ffff';
        if (powerUp.type === 'shield') color = '#4169E1';
        else if (powerUp.type === 'speed') color = '#00FF00';
        else if (powerUp.type === 'slow') color = '#9370DB';
        
        this.particleSystem.createParticles({
          x: powerUp.x,
          y: powerUp.y,
          color: color,
          type: 'collect',
          count: 30
        });

        // Play collection sound with different pitch
        this.audioManager.playCollectSound();
      }
    }

    // Check orb collisions
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const orb = this.orbs[i];
      if (orb.checkCollision(this.player.x, this.player.y, this.player.radius)) {
        orb.collect();
        this.orbs.splice(i, 1);
        
        // Increment combo
        gameStore.incrementCombo();
        
        // Calculate score with combo multiplier
        const basePoints = 100 + (gameStore.level * 10);
        const comboMultiplier = Math.max(1, gameStore.combo);
        const points = basePoints * comboMultiplier;
        gameStore.collectOrb(points);
        
        // Create more particles for higher combos
        const particleCount = 20 + Math.min(gameStore.combo * 5, 30);
        this.particleSystem.createParticles({
          x: orb.x,
          y: orb.y,
          color: gameStore.combo > 3 ? '#ffff00' : '#ffffff',
          type: 'collect',
          count: particleCount
        });

        // Play collection sound
        this.audioManager.playCollectSound();
        
        // Update orb count
        gameStore.setOrbCount(this.orbs.length, gameStore.totalOrbs);
      }
    }

    // Check enemy collisions (only if not invulnerable)
    if (this.invulnerabilityTimer <= 0) {
      for (const enemy of this.enemies) {
        if (enemy.checkCollision(this.player.x, this.player.y, this.player.radius)) {
          // Check if player has shield
          if (gameStore.hasPowerUp('shield')) {
            // Remove shield instead of losing life
            const { activePowerUps } = gameStore;
            const filtered = activePowerUps.filter(p => p.type !== 'shield');
            gameStore.activePowerUps = filtered;
            
            // Create shield break particles
            this.particleSystem.createParticles({
              x: this.player.x,
              y: this.player.y,
              color: '#4169E1',
              type: 'explosion',
              count: 35
            });
            
            // Screen shake for shield break
            this.shakeScreen(5, 20);
            
            // Set brief invulnerability
            this.invulnerabilityTimer = 60;
          } else {
            // Lose a life
            gameStore.loseLife();
            
            // Reset combo on hit
            gameStore.resetCombo();
            
            // Create explosion particles
            this.particleSystem.createParticles({
              x: this.player.x,
              y: this.player.y,
              color: '#ff0040',
              type: 'explosion',
              count: 25
            });

            // Play hit sound
            this.audioManager.playHitSound();
            
            // Screen shake for hit
            this.shakeScreen(10, 30);
            
            // Set invulnerability period
            this.invulnerabilityTimer = 120; // 2 seconds at 60fps
            
            // Check if game over
            if (gameStore.lives <= 0) {
              this.gameState = 'GAME_OVER';
              gameStore.gameOver();
              return;
            } else {
              // Reset level on life loss
              this.setupLevel();
              return;
            }
          }
          
          // Play hit sound regardless
          this.audioManager.playHitSound();
          break; // Only process one collision per frame
        }
      }
    }

    // Check if level complete
    if (this.orbs.length === 0) {
      this.gameState = 'LEVEL_TRANSITION';
      gameStore.levelComplete();
      
      // Create level completion particles
      this.particleSystem.createParticles({
        x: this.player.x,
        y: this.player.y,
        color: '#ffff00',
        type: 'levelup',
        count: 50
      });

      // Play level complete sound
      this.audioManager.playLevelCompleteSound();
      
      // Screen shake for level complete
      this.shakeScreen(8, 40);
      
      this.levelTransitionTimer = 180; // 3 seconds
    }

    // Handle level transition
    if (this.gameState === 'LEVEL_TRANSITION') {
      this.levelTransitionTimer--;
      if (this.levelTransitionTimer <= 0) {
        gameStore.nextLevel();
        this.gameState = 'PLAYING';
        this.setupLevel();
      }
    }
  }

  private draw() {
    const { width, height } = this.canvas;
    
    // Apply screen shake
    this.ctx.save();
    if (this.shakeIntensity > 0) {
      const offsetX = (Math.random() - 0.5) * this.shakeIntensity;
      const offsetY = (Math.random() - 0.5) * this.shakeIntensity;
      this.ctx.translate(offsetX, offsetY);
    }
    
    // Clear with fade effect for trails
    this.ctx.fillStyle = 'rgba(2, 2, 10, 0.15)';
    this.ctx.fillRect(0, 0, width, height);

    // Draw background with theme
    const gradient = this.ctx.createRadialGradient(
      width / 2, height / 2, 0,
      width / 2, height / 2, Math.max(width, height) / 2
    );
    gradient.addColorStop(0, this.currentTheme.backgroundColor.start);
    gradient.addColorStop(1, this.currentTheme.backgroundColor.end);
    this.ctx.fillStyle = gradient;
    this.ctx.fillRect(0, 0, width, height);

    // Draw background dust with theme color
    this.dustParticles.forEach(dust => {
      this.ctx.beginPath();
      this.ctx.fillStyle = this.currentTheme.dustColor.replace('0.3', String(dust.alpha));
      this.ctx.arc(dust.x, dust.y, dust.radius, 0, Math.PI * 2);
      this.ctx.fill();
    });

    if (this.gameState === 'PLAYING' || this.gameState === 'LEVEL_TRANSITION') {
      // Draw orbs
      this.orbs.forEach(orb => orb.draw(this.ctx));

      // Draw power-ups
      this.powerUps.forEach(powerUp => powerUp.draw(this.ctx));

      // Draw enemies
      this.enemies.forEach(enemy => enemy.draw(this.ctx));

      // Draw player (with flashing effect if invulnerable)
      if (this.invulnerabilityTimer <= 0 || Math.floor(this.invulnerabilityTimer / 5) % 2 === 0) {
        this.player.draw(this.ctx);
        
        // Draw shield visual if active
        const gameStore = useGameStore.getState();
        if (gameStore.hasPowerUp('shield')) {
          const pulseMagnitude = 1 + Math.sin(Date.now() / 200) * 0.1;
          const shieldRadius = (this.player.radius + 10) * pulseMagnitude;
          
          const gradient = this.ctx.createRadialGradient(
            this.player.x, this.player.y, this.player.radius,
            this.player.x, this.player.y, shieldRadius
          );
          gradient.addColorStop(0, 'rgba(65, 105, 225, 0)');
          gradient.addColorStop(0.7, 'rgba(65, 105, 225, 0.3)');
          gradient.addColorStop(1, 'rgba(30, 144, 255, 0.6)');
          
          this.ctx.beginPath();
          this.ctx.arc(this.player.x, this.player.y, shieldRadius, 0, Math.PI * 2);
          this.ctx.fillStyle = gradient;
          this.ctx.fill();
          
          this.ctx.strokeStyle = '#4169E1';
          this.ctx.lineWidth = 2;
          this.ctx.stroke();
        }
      }
    }

    // Draw particles on top
    this.particleSystem.draw(this.ctx);
    
    // Restore context after shake
    this.ctx.restore();
  }

  private shakeScreen(intensity: number, duration: number) {
    this.shakeIntensity = intensity;
    this.shakeDuration = duration;
  }

  private gameLoop = (currentTime: number) => {
    if (!this.isRunning) return;

    const deltaTime = currentTime - this.lastTime;
    this.lastTime = currentTime;

    this.update(deltaTime);
    this.draw();

    this.animationId = requestAnimationFrame(this.gameLoop);
  };

  public start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.lastTime = performance.now();
    this.gameLoop(this.lastTime);
  }

  public stop() {
    this.isRunning = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }

  public setGameState(state: string) {
    this.gameState = state;
    
    if (state === 'PLAYING' && (this.orbs.length === 0 || this.enemies.length === 0)) {
      this.setupLevel();
    }
  }

  public handleResize() {
    const { width, height } = this.canvas;
    this.player.resize(width, height);
    this.enemies.forEach(enemy => enemy.resize(width, height));
    this.generateDustParticles();
  }
}
