import * as Tone from 'tone';

export class AudioManager {
  private static instance: AudioManager;
  private initialized = false;
  private _isMuted = false;
  
  // Audio synthesizers
  private collectSynth: Tone.MetalSynth | null = null;
  private hitSynth: Tone.MembraneSynth | null = null;
  private levelCompleteSynth: Tone.PolySynth | null = null;
  private backgroundSynth: Tone.Synth | null = null;

  private constructor() {
    // Private constructor for singleton
  }

  public static getInstance(): AudioManager {
    if (!AudioManager.instance) {
      AudioManager.instance = new AudioManager();
    }
    return AudioManager.instance;
  }

  public async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      await Tone.start();
      
      // Collection sound - bright metallic chime
      this.collectSynth = new Tone.MetalSynth({
        frequency: 800,
        envelope: { attack: 0.001, decay: 0.1, release: 0.05 },
        harmonicity: 12,
        modulationIndex: 25,
        resonance: 4000,
        octaves: 1.5,
        volume: -12
      }).toDestination();

      // Hit sound - deep impact
      this.hitSynth = new Tone.MembraneSynth({
        pitchDecay: 0.08,
        octaves: 2,
        envelope: { attack: 0.001, decay: 0.3, sustain: 0.01, release: 0.1 },
        volume: -8
      }).toDestination();

      // Level complete sound - triumphant chord
      this.levelCompleteSynth = new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'triangle' },
        envelope: { attack: 0.01, decay: 0.2, sustain: 0.3, release: 0.8 },
        volume: -10
      }).toDestination();

      // Background ambience
      this.backgroundSynth = new Tone.Synth({
        oscillator: { type: 'sine' },
        envelope: { attack: 2, decay: 1, sustain: 0.1, release: 2 },
        volume: -25
      }).toDestination();

      this.initialized = true;
    } catch (error) {
      console.warn('Audio initialization failed:', error);
    }
  }

  public playCollectSound(): void {
    if (!this.initialized || this._isMuted || !this.collectSynth) return;
    
    try {
      // Random pitch for variety
      const pitch = 400 + Math.random() * 800;
      this.collectSynth.frequency.setValueAtTime(pitch, Tone.now());
      this.collectSynth.triggerAttackRelease('16n');
    } catch (error) {
      console.warn('Failed to play collect sound:', error);
    }
  }

  public playHitSound(): void {
    if (!this.initialized || this._isMuted || !this.hitSynth) return;
    
    try {
      this.hitSynth.triggerAttackRelease('C1', '8n');
    } catch (error) {
      console.warn('Failed to play hit sound:', error);
    }
  }

  public playLevelCompleteSound(): void {
    if (!this.initialized || this._isMuted || !this.levelCompleteSynth) return;
    
    try {
      // Play a triumphant chord progression
      const now = Tone.now();
      this.levelCompleteSynth.triggerAttackRelease(['C4', 'E4', 'G4'], '2n', now);
      this.levelCompleteSynth.triggerAttackRelease(['F4', 'A4', 'C5'], '2n', now + 0.3);
      this.levelCompleteSynth.triggerAttackRelease(['C5', 'E5', 'G5'], '1n', now + 0.6);
    } catch (error) {
      console.warn('Failed to play level complete sound:', error);
    }
  }

  public playBackgroundAmbience(): void {
    if (!this.initialized || this._isMuted || !this.backgroundSynth) return;
    
    try {
      // Subtle ambient drone
      this.backgroundSynth.triggerAttack('C2');
    } catch (error) {
      console.warn('Failed to play background sound:', error);
    }
  }

  public stopBackgroundAmbience(): void {
    if (!this.backgroundSynth) return;
    
    try {
      this.backgroundSynth.triggerRelease();
    } catch (error) {
      console.warn('Failed to stop background sound:', error);
    }
  }

  public toggleMute(): void {
    this._isMuted = !this._isMuted;
    
    if (this._isMuted) {
      this.stopBackgroundAmbience();
    }
  }

  public get isMuted(): boolean {
    return this._isMuted;
  }

  public setMuted(muted: boolean): void {
    this._isMuted = muted;
    
    if (muted) {
      this.stopBackgroundAmbience();
    }
  }
}
