import { useGameStore, Difficulty } from '@/lib/stores/useGameStore';
import { useHighScore } from '@/lib/stores/useHighScore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Trophy, Keyboard, Smartphone, Heart, Zap, Flame, Infinity } from 'lucide-react';
import { AudioManager } from '@/lib/audio/AudioManager';
import { useState } from 'react';

const StartScreen = () => {
  const { startGame, setDifficulty } = useGameStore();
  const { highScore } = useHighScore();
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('normal');

  const handleStart = async () => {
    // Initialize audio context on user interaction
    await AudioManager.getInstance().initialize();
    setDifficulty(selectedDifficulty);
    startGame(selectedDifficulty);
  };

  const difficulties = [
    { id: 'easy' as Difficulty, label: 'Easy', icon: Heart, color: 'green', description: '5 Lives • Slower Enemies' },
    { id: 'normal' as Difficulty, label: 'Normal', icon: Zap, color: 'blue', description: '3 Lives • Standard' },
    { id: 'hard' as Difficulty, label: 'Hard', icon: Flame, color: 'orange', description: '2 Lives • Faster Enemies' },
    { id: 'endless' as Difficulty, label: 'Endless', icon: Infinity, color: 'purple', description: '1 Life • Maximum Challenge' }
  ];

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm z-20">
      <div className="max-w-md w-full mx-4 text-center">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 mb-4 animate-pulse font-mono">
            LIGHTBOUND
          </h1>
          <p className="text-lg text-white/80 leading-relaxed">
            You are light, and this world is forgetting color.
            <br />
            <span className="text-cyan-400">Reconnect the fragments</span> and paint the void with your glow.
          </p>
        </div>

        {/* High Score Display */}
        {highScore > 0 && (
          <Card className="mb-6 bg-black/80 border-yellow-500/30">
            <CardContent className="pt-4">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Trophy className="w-5 h-5 text-yellow-400" />
                <span className="text-yellow-400 font-bold">BEST SCORE</span>
              </div>
              <div className="text-2xl font-mono text-white">
                {highScore.toLocaleString()}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Difficulty Selection */}
        <div className="mb-8">
          <h3 className="text-white/80 text-sm font-bold mb-3 text-center">SELECT DIFFICULTY</h3>
          <div className="grid grid-cols-2 gap-2">
            {difficulties.map((diff) => {
              const Icon = diff.icon;
              const isSelected = selectedDifficulty === diff.id;
              
              let borderStyle, bgStyle, iconColor, textColor;
              if (isSelected) {
                if (diff.color === 'green') {
                  borderStyle = 'border-green-500';
                  bgStyle = 'bg-green-500/20';
                  iconColor = 'text-green-400';
                  textColor = 'text-green-400';
                } else if (diff.color === 'blue') {
                  borderStyle = 'border-blue-500';
                  bgStyle = 'bg-blue-500/20';
                  iconColor = 'text-blue-400';
                  textColor = 'text-blue-400';
                } else if (diff.color === 'orange') {
                  borderStyle = 'border-orange-500';
                  bgStyle = 'bg-orange-500/20';
                  iconColor = 'text-orange-400';
                  textColor = 'text-orange-400';
                } else {
                  borderStyle = 'border-purple-500';
                  bgStyle = 'bg-purple-500/20';
                  iconColor = 'text-purple-400';
                  textColor = 'text-purple-400';
                }
              } else {
                borderStyle = 'border-white/20';
                bgStyle = 'bg-black/40';
                iconColor = 'text-white/60';
                textColor = 'text-white/80';
              }
              
              return (
                <button
                  key={diff.id}
                  onClick={() => setSelectedDifficulty(diff.id)}
                  className={`p-3 rounded-lg border-2 transition-all ${borderStyle} ${bgStyle} hover:border-white/40`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={`w-4 h-4 ${iconColor}`} />
                    <span className={`font-bold text-sm ${textColor}`}>
                      {diff.label}
                    </span>
                  </div>
                  <p className={`text-xs ${isSelected ? 'text-white/80' : 'text-white/40'}`}>
                    {diff.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="bg-black/60 border-white/20">
            <CardContent className="pt-4">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Keyboard className="w-5 h-5 text-cyan-400" />
                <span className="text-cyan-400 font-bold text-sm">DESKTOP</span>
              </div>
              <div className="text-white/80 text-xs">
                Arrow Keys or WASD
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/60 border-white/20">
            <CardContent className="pt-4">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Smartphone className="w-5 h-5 text-purple-400" />
                <span className="text-purple-400 font-bold text-sm">MOBILE</span>
              </div>
              <div className="text-white/80 text-xs">
                Touch and Drag
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Features */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <Badge variant="outline" className="text-cyan-400 border-cyan-400/50">
            Collect Orbs
          </Badge>
          <Badge variant="outline" className="text-red-400 border-red-400/50">
            Avoid Enemies
          </Badge>
          <Badge variant="outline" className="text-purple-400 border-purple-400/50">
            Endless Levels
          </Badge>
          <Badge variant="outline" className="text-green-400 border-green-400/50">
            High Scores
          </Badge>
        </div>

        {/* Start Button */}
        <Button 
          onClick={handleStart}
          size="lg"
          className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold py-4 text-lg transition-all duration-300 transform hover:scale-105"
        >
          <Play className="w-6 h-6 mr-2" />
          START GAME
        </Button>

        <p className="text-white/60 text-sm mt-4">
          Click to begin your luminous journey
        </p>
      </div>
    </div>
  );
};

export default StartScreen;
