import { useGameStore } from '@/lib/stores/useGameStore';
import { useHighScore } from '@/lib/stores/useHighScore';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Heart, Pause, Volume2, VolumeX, Trophy, Shield, Zap, Snowflake } from 'lucide-react';
import { AudioManager } from '@/lib/audio/AudioManager';

const GameUI = () => {
  const { 
    score, 
    level, 
    lives, 
    orbsRemaining, 
    totalOrbs, 
    gameState, 
    pauseGame, 
    isPaused,
    combo,
    comboTimer,
    activePowerUps
  } = useGameStore();
  
  const { highScore } = useHighScore();
  const audioManager = AudioManager.getInstance();

  const handlePause = () => {
    pauseGame();
  };

  const toggleMute = () => {
    audioManager.toggleMute();
  };

  const orbProgress = totalOrbs > 0 ? ((totalOrbs - orbsRemaining) / totalOrbs) * 100 : 0;

  return (
    <div className="absolute inset-0 pointer-events-none z-10">
      {/* Top HUD */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start pointer-events-auto">
        {/* Left side - Score and Level */}
        <div className="space-y-2">
          <div className="bg-black/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-cyan-500/30">
            <div className="text-cyan-400 text-sm font-bold">SCORE</div>
            <div className="text-white text-2xl font-mono tracking-wider">
              {score.toLocaleString()}
            </div>
          </div>
          
          <div className="bg-black/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-purple-500/30">
            <div className="text-purple-400 text-sm font-bold">LEVEL</div>
            <div className="text-white text-xl font-mono">{level}</div>
          </div>
          
          {/* High Score Display */}
          <div className="bg-black/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-yellow-500/30">
            <div className="flex items-center gap-1 text-yellow-400 text-sm font-bold">
              <Trophy className="w-3 h-3" />
              HIGH SCORE
            </div>
            <div className="text-white text-lg font-mono">
              {highScore.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Right side - Controls */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={toggleMute}
            className="bg-black/80 backdrop-blur-sm border-gray-500/30 hover:border-cyan-500/50 text-white"
          >
            {audioManager.isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={handlePause}
            className="bg-black/80 backdrop-blur-sm border-gray-500/30 hover:border-cyan-500/50 text-white"
          >
            <Pause className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Bottom HUD */}
      <div className="absolute bottom-0 left-0 right-0 p-4 pointer-events-auto">
        {/* Active Power-ups */}
        {activePowerUps.length > 0 && (
          <div className="flex justify-center mb-4 gap-2">
            {activePowerUps.map((powerUp, index) => {
              const Icon = powerUp.type === 'shield' ? Shield : powerUp.type === 'speed' ? Zap : Snowflake;
              const progress = powerUp.type !== 'shield' ? (powerUp.duration / 300) * 100 : 100;
              
              let borderColor, textColor, bgColor;
              if (powerUp.type === 'shield') {
                borderColor = 'border-blue-500/30';
                textColor = 'text-blue-400';
                bgColor = '#3b82f6';
              } else if (powerUp.type === 'speed') {
                borderColor = 'border-green-500/30';
                textColor = 'text-green-400';
                bgColor = '#22c55e';
              } else {
                borderColor = 'border-purple-500/30';
                textColor = 'text-purple-400';
                bgColor = '#a855f7';
              }
              
              return (
                <div key={index} className={`bg-black/80 backdrop-blur-sm rounded-lg px-4 py-2 border ${borderColor} relative overflow-hidden`}>
                  <div className="flex items-center gap-2">
                    <Icon className={`w-4 h-4 ${textColor}`} />
                    <span className={`${textColor} text-sm font-bold uppercase`}>
                      {powerUp.type}
                    </span>
                  </div>
                  {powerUp.type !== 'shield' && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/60">
                      <div 
                        className="h-full transition-all duration-100"
                        style={{ width: `${progress}%`, backgroundColor: bgColor }}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Lives */}
        <div className="flex justify-center mb-4">
          <div className="bg-black/80 backdrop-blur-sm rounded-lg px-6 py-3 border border-red-500/30">
            <div className="flex items-center gap-2">
              <span className="text-red-400 text-sm font-bold">LIVES</span>
              <div className="flex gap-1">
                {Array.from({ length: Math.max(0, lives) }).map((_, i) => (
                  <Heart key={i} className="w-4 h-4 fill-red-500 text-red-500" />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Orb Collection Progress */}
        <div className="bg-black/80 backdrop-blur-sm rounded-lg p-4 border border-white/20">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white text-sm font-bold">ORBS COLLECTED</span>
            <Badge variant="outline" className="text-cyan-400 border-cyan-400/50">
              {totalOrbs - orbsRemaining} / {totalOrbs}
            </Badge>
          </div>
          <Progress 
            value={orbProgress} 
            className="h-2 bg-gray-800"
            style={{
              background: 'linear-gradient(to right, rgba(6, 182, 212, 0.2), rgba(6, 182, 212, 0.1))'
            }}
          />
        </div>
      </div>

      {/* Level Transition Overlay */}
      {gameState === 'LEVEL_TRANSITION' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm pointer-events-auto">
          <div className="text-center">
            <div className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-600 mb-4 animate-pulse">
              LEVEL {level}
            </div>
            <div className="text-xl text-white/80">
              Prepare for the next challenge...
            </div>
          </div>
        </div>
      )}

      {/* Combo Display - Center Top */}
      {combo > 1 && (
        <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
          <div className="text-center animate-bounce">
            <div className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 mb-2">
              {combo}x
            </div>
            <div className="text-xl text-white font-bold bg-black/60 px-4 py-1 rounded-full border border-yellow-400/50">
              COMBO!
            </div>
            {/* Combo Timer Bar */}
            <div className="mt-2 w-32 h-2 bg-black/60 rounded-full overflow-hidden border border-yellow-400/30 mx-auto">
              <div 
                className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-100"
                style={{ width: `${(comboTimer / 120) * 100}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Mobile Touch Instructions */}
      <div className="absolute bottom-20 left-4 right-4 text-center pointer-events-none md:hidden">
        <div className="text-white/60 text-sm">
          Touch and drag to move • Collect all glowing orbs
        </div>
      </div>
    </div>
  );
};

export default GameUI;
