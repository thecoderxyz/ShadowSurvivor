import { useGameStore } from '@/lib/stores/useGameStore';
import { useHighScore } from '@/lib/stores/useHighScore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RotateCcw, Trophy, Star, Target, Zap } from 'lucide-react';
import { useEffect, useState } from 'react';

const GameOverScreen = () => {
  const { score, level, restartGame, maxCombo } = useGameStore();
  const { highScore, updateHighScore } = useHighScore();
  const [isNewRecord, setIsNewRecord] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    const wasNewRecord = updateHighScore(score);
    setIsNewRecord(wasNewRecord);
    
    if (wasNewRecord) {
      setShowConfetti(true);
      // Hide confetti after animation
      setTimeout(() => setShowConfetti(false), 3000);
    }
  }, [score, updateHighScore]);

  const handleRestart = () => {
    restartGame();
  };

  const getScoreRank = () => {
    if (score >= 10000) return { rank: 'LEGENDARY', color: 'text-yellow-400', icon: Trophy };
    if (score >= 5000) return { rank: 'MASTER', color: 'text-purple-400', icon: Star };
    if (score >= 2500) return { rank: 'EXPERT', color: 'text-blue-400', icon: Target };
    if (score >= 1000) return { rank: 'SKILLED', color: 'text-green-400', icon: Zap };
    return { rank: 'NOVICE', color: 'text-gray-400', icon: Target };
  };

  const scoreRank = getScoreRank();
  const RankIcon = scoreRank.icon;

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/90 backdrop-blur-sm z-20">
      {/* Confetti Effect for New Records */}
      {showConfetti && isNewRecord && (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${1 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      )}

      <div className="max-w-lg w-full mx-4 text-center">
        {/* Game Over Title */}
        <div className="mb-6">
          <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-pink-500 to-purple-600 mb-2 font-mono">
            GAME OVER
          </h1>
          <p className="text-white/60 text-lg">
            The light has faded, but the journey continues...
          </p>
        </div>

        {/* New Record Banner */}
        {isNewRecord && (
          <div className="mb-6 animate-pulse">
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold py-2 px-4 text-lg">
              🎉 NEW HIGH SCORE! 🎉
            </Badge>
          </div>
        )}

        {/* Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Final Score */}
          <Card className="bg-black/80 border-cyan-500/30">
            <CardContent className="pt-4">
              <div className="text-cyan-400 text-sm font-bold mb-2">FINAL SCORE</div>
              <div className="text-3xl font-mono text-white font-bold">
                {score.toLocaleString()}
              </div>
              <div className="flex items-center justify-center gap-1 mt-2">
                <RankIcon className={`w-4 h-4 ${scoreRank.color}`} />
                <span className={`text-xs font-bold ${scoreRank.color}`}>
                  {scoreRank.rank}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Level Reached */}
          <Card className="bg-black/80 border-purple-500/30">
            <CardContent className="pt-4">
              <div className="text-purple-400 text-sm font-bold mb-2">LEVEL REACHED</div>
              <div className="text-3xl font-mono text-white font-bold">
                {level}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* High Score Display */}
        <Card className="mb-6 bg-black/80 border-yellow-500/30">
          <CardContent className="pt-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-bold">BEST SCORE</span>
            </div>
            <div className="text-2xl font-mono text-white">
              {highScore.toLocaleString()}
            </div>
          </CardContent>
        </Card>

        {/* Game Stats */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <Badge variant="outline" className="text-cyan-400 border-cyan-400/50">
            Orbs Collected: {Math.floor(score / 100)}
          </Badge>
          <Badge variant="outline" className="text-purple-400 border-purple-400/50">
            Levels Survived: {level - 1}
          </Badge>
          {maxCombo > 1 && (
            <Badge variant="outline" className="text-yellow-400 border-yellow-400/50">
              Max Combo: {maxCombo}x
            </Badge>
          )}
        </div>

        {/* Restart Button */}
        <Button 
          onClick={handleRestart}
          size="lg"
          className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white font-bold py-4 text-lg transition-all duration-300 transform hover:scale-105"
        >
          <RotateCcw className="w-6 h-6 mr-2" />
          PLAY AGAIN
        </Button>

        <p className="text-white/60 text-sm mt-4">
          Rise again and reclaim the light!
        </p>
      </div>
    </div>
  );
};

export default GameOverScreen;
