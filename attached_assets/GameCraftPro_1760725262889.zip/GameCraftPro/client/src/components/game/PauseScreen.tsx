import { useGameStore } from '@/lib/stores/useGameStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Play, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import { AudioManager } from '@/lib/audio/AudioManager';

const PauseScreen = () => {
  const { resumeGame, restartGame, score, level } = useGameStore();
  const audioManager = AudioManager.getInstance();

  const handleResume = () => {
    resumeGame();
  };

  const handleRestart = () => {
    restartGame();
  };

  const toggleMute = () => {
    audioManager.toggleMute();
  };

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm z-20">
      <div className="max-w-md w-full mx-4 text-center">
        {/* Pause Title */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-4 font-mono">
            PAUSED
          </h1>
          <p className="text-white/80">
            Take a moment to breathe in the void
          </p>
        </div>

        {/* Current Stats */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <Card className="bg-black/80 border-cyan-500/30">
            <CardContent className="pt-4">
              <div className="text-cyan-400 text-sm font-bold mb-1">SCORE</div>
              <div className="text-xl font-mono text-white">
                {score.toLocaleString()}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 border-purple-500/30">
            <CardContent className="pt-4">
              <div className="text-purple-400 text-sm font-bold mb-1">LEVEL</div>
              <div className="text-xl font-mono text-white">
                {level}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button 
            onClick={handleResume}
            size="lg"
            className="w-full bg-gradient-to-r from-green-500 to-cyan-600 hover:from-green-600 hover:to-cyan-700 text-white font-bold py-3"
          >
            <Play className="w-5 h-5 mr-2" />
            RESUME GAME
          </Button>

          <Button 
            onClick={toggleMute}
            variant="outline"
            size="lg"
            className="w-full bg-black/60 border-gray-500/30 hover:border-cyan-500/50 text-white"
          >
            {audioManager.isMuted ? (
              <>
                <VolumeX className="w-5 h-5 mr-2" />
                UNMUTE SOUND
              </>
            ) : (
              <>
                <Volume2 className="w-5 h-5 mr-2" />
                MUTE SOUND
              </>
            )}
          </Button>

          <Button 
            onClick={handleRestart}
            variant="outline"
            size="lg"
            className="w-full bg-black/60 border-red-500/30 hover:border-red-500/50 text-white hover:text-red-400"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            RESTART GAME
          </Button>
        </div>

        <p className="text-white/60 text-sm mt-6">
          Press ESC or click Resume to continue
        </p>
      </div>
    </div>
  );
};

export default PauseScreen;
