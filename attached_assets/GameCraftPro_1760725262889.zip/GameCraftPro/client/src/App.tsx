import { useEffect } from 'react';
import GameCanvas from './components/game/GameCanvas';
import GameUI from './components/game/GameUI';
import StartScreen from './components/game/StartScreen';
import GameOverScreen from './components/game/GameOverScreen';
import PauseScreen from './components/game/PauseScreen';
import { useGameStore } from './lib/stores/useGameStore';
import { AudioManager } from './lib/audio/AudioManager';
import "@fontsource/inter";

function App() {
  const { gameState, initializeGame } = useGameStore();

  useEffect(() => {
    // Initialize the game on mount
    initializeGame();
    
    // Initialize audio manager
    AudioManager.getInstance();
    
    // Prevent context menu on right click
    const handleContextMenu = (e: Event) => e.preventDefault();
    document.addEventListener('contextmenu', handleContextMenu);
    
    // Prevent scrolling on mobile
    const preventScroll = (e: TouchEvent) => {
      e.preventDefault();
    };
    document.addEventListener('touchmove', preventScroll, { passive: false });
    
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('touchmove', preventScroll);
    };
  }, [initializeGame]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gray-900">
      {/* Game Canvas - Always rendered for smooth transitions */}
      <GameCanvas />
      
      {/* UI Overlays */}
      {gameState === 'START' && <StartScreen />}
      {gameState === 'GAME_OVER' && <GameOverScreen />}
      {gameState === 'PAUSED' && <PauseScreen />}
      {(gameState === 'PLAYING' || gameState === 'LEVEL_TRANSITION') && <GameUI />}
      
      {/* Background gradient overlay for better visual appeal */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-radial from-transparent via-transparent to-black/20" />
    </div>
  );
}

export default App;
